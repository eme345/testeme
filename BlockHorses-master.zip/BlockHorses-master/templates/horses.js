module.exports = function () {

    return horses = [
        {color: 'White', mane: 'White', tail: 'White', shoes: 'White', eye: 'White', unicorn: 'White', wings: 'White'},
        {color: 'DimGrey', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Grey'},
        {color: 'Lavender', mane: 'Purple', tail: 'Purple', shoes: 'Indigo', eye: 'Pink', unicorn: 'Gold', wings: 'GoldenRod'},
        {color: 'DarkBlue', mane: 'DarkSlateGrey', tail: 'DarkSlateGrey', shoes: 'Black', eye: 'Blue', wings: 'Yellow'},
        {color: 'Coral', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Purple', mane: 'Gold', tail: 'Gold', shoes: 'Black', eye: 'Orange', unicorn: 'GoldenRod', wings: 'GoldenRod'}, // KJC
        {color: 'Orange', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'} , // ABC
        {color: 'DarkCyan', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink', unicorn: 'GoldenRod'} , // AMC
        {color: 'DeepPink', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'} , // S
        {color: 'AliceBlue ', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'} , // K
        {color: 'CornSilk', mane: 'Grey', tail: 'Grey', shoes: 'Grey', eye: 'Pink', unicorn: 'GoldenRod'} , // SF 
        {color: 'Azure', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'} , // X
        {color: 'Ivory', mane: 'DarkViolet', tail: 'DarkViolet', shoes: 'Black', eye: 'Pink'} , // T
        {color: 'Indigo', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},  // A
        {color: 'AntiqueWhite', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Aqua', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Aquamarine', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Beige', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Bisque', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'BlanchedAlmond', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Blue', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'BlueViolet', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Brown', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'BurlyWood', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'CadetBlue', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Chartreuse', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Chocolate', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'CornflowerBlue', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Crimson', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Cyan', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'DarkBlue', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'DarkCyan', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'DarkGoldenRod', mane: 'Black', tail: 'Black', shoes: 'Black', eye: 'Pink'},
        {color: 'Brown', mane: 'Gold', tail: 'Green', shoes: 'Black', eye: 'Red'},
        {color: 'Aquamarine', mane: 'CornSilk', tail: 'CornSilk', shoes: 'GoldenRod', eye: 'Grey', unicorn: 'GoldenRod', wings: 'GoldenRod'}
        
    ]
}