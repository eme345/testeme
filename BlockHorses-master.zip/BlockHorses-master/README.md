# Block Horses
Block Horses inspired by CrytoPunks, CryptoKitties and CryptoCats inbetween

Generate horses
```
npm run generate
```

Build website
```
npm run build
```

Dev
```
npm run dev
```